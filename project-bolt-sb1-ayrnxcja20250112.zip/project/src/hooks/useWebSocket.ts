import { useEffect, useRef, useState } from 'react';
import type { SetupProgress } from '../types/setup';

export function useWebSocket() {
  const [progress, setProgress] = useState<SetupProgress | null>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    const connectWebSocket = () => {
      if (reconnectAttempts.current >= maxReconnectAttempts) {
        console.error('WebSocket接続の最大試行回数に達しました');
        return;
      }

      // 既存の接続を閉じる
      if (wsRef.current) {
        wsRef.current.close();
      }

      // WebSocketのURLをViteの開発サーバーのプロキシに合わせる
      const wsUrl = `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.host}/ws`;
      
      wsRef.current = new WebSocket(wsUrl);

      wsRef.current.onopen = () => {
        console.log('WebSocket接続が確立されました');
        reconnectAttempts.current = 0;
      };

      wsRef.current.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          setProgress(data);
        } catch (error) {
          console.error('WebSocketメッセージの解析エラー:', error);
        }
      };

      wsRef.current.onerror = (error) => {
        console.error('WebSocketエラー:', error);
      };

      wsRef.current.onclose = (event) => {
        console.log(`WebSocket接続が閉じられました (コード: ${event.code})`);
        
        // 正常なクローズでない場合のみ再接続を試みる
        if (event.code !== 1000) {
          reconnectAttempts.current++;
          
          // 再接続を試みる
          const timeout = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000);
          reconnectTimeoutRef.current = setTimeout(() => {
            if (wsRef.current?.readyState === WebSocket.CLOSED) {
              connectWebSocket();
            }
          }, timeout);
        }
      };
    };

    connectWebSocket();

    // クリーンアップ関数
    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  return { progress };
}