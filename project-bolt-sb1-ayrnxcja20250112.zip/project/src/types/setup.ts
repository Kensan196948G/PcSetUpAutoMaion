// セットアップタイプの定義
export type SetupType = 'AD' | 'LOCAL' | 'NEW_LOCAL';

// セットアップステータスの定義
export type SetupStatusType = 'pending' | 'running' | 'completed' | 'error';

// インストールオプションの定義
export interface InstallOptions {
  office365: boolean;
  carbonBlack: boolean;
  aresStandard: boolean;
  trendMicroApexOne: boolean;
  trendMicroVirusBuster: boolean;
  jp1Director: boolean;
  dvdSoftware: boolean;
  fortiClientVpn: boolean;
}

// Windows Update設定の定義
export interface WindowsUpdateSettings {
  enabled: boolean;
  microsoftUpdate: boolean;
  systemCleanup: boolean;
  diskCleanup: boolean;
  autoRestart: boolean;
}

// OS設定の定義
export interface OSSettings {
  desktopIcons: boolean;
  disableIpv6: boolean;
  disableWindowsDefenderFw: boolean;
  unpinMailStore: boolean;
  edgeDefaultSites: boolean;
  edgeDefaultBrowser: boolean;
  defaultMailProgram: boolean;  // メール用の設定
  defaultPdfProgram: boolean;   // PDF用の設定
  windowsUpdate: WindowsUpdateSettings;
}

// エラー情報の定義
export interface SetupError {
  message: string;
  stack?: string;
}

// セットアップステータスの定義
export interface SetupStatus {
  step: string;
  status: SetupStatusType;
  message: string;
  error?: SetupError;
}

// サブステップ情報の定義
export interface SetupSubstep {
  current: number;
  total: number;
  name: string;
}

// セットアップ進捗の定義
export interface SetupProgress {
  currentStep: number;
  totalSteps: number;
  status: SetupStatus;
  substeps?: SetupSubstep;
}

// メインのセットアップ設定の定義
export interface PCSetupConfig {
  hostname: string;
  ipAddress?: string;  // オプショナルに変更（ホスト名があれば十分）
  setupType: SetupType;
  username?: string;
  password?: string;
  fullName?: string;
  isAdmin?: boolean;
  installOptions: InstallOptions;
  osSettings: OSSettings;
}

// セットアップレスポンスの定義
export interface SetupResponse {
  status: 'success' | 'error';
  message: string;
  logPath?: string;
  error?: SetupError;
}

// WebSocketメッセージの定義
export interface WebSocketMessage {
  type: 'progress' | 'error' | 'complete';
  data: SetupProgress | SetupError;
}