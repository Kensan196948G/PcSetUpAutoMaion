import os
import sys
import json
import subprocess
import urllib.request
import zipfile
import winreg
import time
from typing import Dict, Any

def update_progress(step: str, status: str, message: str, current_step: int = 0) -> Dict[str, Any]:
    progress = {
        "currentStep": current_step,
        "totalSteps": 10,
        "status": {
            "step": step,
            "status": status,
            "message": message
        }
    }
    print(json.dumps(progress))
    sys.stdout.flush()
    return progress

def setup_winrm():
    try:
        # WinRMの設定をバッチコマンドで実行
        commands = [
            'winrm quickconfig -force',
            'winrm set winrm/config/service @{AllowUnencrypted="true"}',
            'winrm set winrm/config/service/auth @{Basic="true"}',
            'winrm set winrm/config/client @{TrustedHosts="*"}'
        ]
        
        for cmd in commands:
            subprocess.run(cmd, shell=True, check=True)
        
        return True
    except subprocess.CalledProcessError as e:
        raise Exception(f"WinRM設定エラー: {str(e)}")

def setup_pstools():
    try:
        # PSToolsのダウンロードと展開
        pstools_url = "https://download.sysinternals.com/files/PSTools.zip"
        pstools_path = os.path.join(os.environ['TEMP'], "PSTools.zip")
        pstools_extract_path = os.path.join(os.environ['TEMP'], "PSTools")

        # 既存のファイルを削除
        if os.path.exists(pstools_path):
            os.remove(pstools_path)
        if os.path.exists(pstools_extract_path):
            import shutil
            shutil.rmtree(pstools_extract_path)

        # ダウンロードと展開
        urllib.request.urlretrieve(pstools_url, pstools_path)
        with zipfile.ZipFile(pstools_path, 'r') as zip_ref:
            zip_ref.extractall(pstools_extract_path)

        # PATHに追加
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SYSTEM\CurrentControlSet\Control\Session Manager\Environment', 0, winreg.KEY_ALL_ACCESS)
        current_path = winreg.QueryValueEx(key, 'Path')[0]
        if pstools_extract_path not in current_path:
            new_path = f"{current_path};{pstools_extract_path}"
            winreg.SetValueEx(key, 'Path', 0, winreg.REG_EXPAND_SZ, new_path)
        winreg.CloseKey(key)

        return True
    except Exception as e:
        raise Exception(f"PSToolsセットアップエラー: {str(e)}")

def configure_windows_update():
    try:
        # Windows Update設定をバッチコマンドで実行
        commands = [
            'reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WindowsUpdate\\Auto Update" /v AUOptions /t REG_DWORD /d 4 /f',
            'reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WindowsUpdate\\Auto Update" /v ScheduledInstallDay /t REG_DWORD /d 0 /f',
            'reg add "HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\WindowsUpdate\\Auto Update" /v ScheduledInstallTime /t REG_DWORD /d 3 /f',
            'net stop wuauserv',
            'net start wuauserv'
        ]
        
        for cmd in commands:
            subprocess.run(cmd, shell=True, check=True)
            
        return True
    except subprocess.CalledProcessError as e:
        raise Exception(f"Windows Update設定エラー: {str(e)}")

def install_software(software_name: str):
    # ソフトウェアインストールのモック実装
    time.sleep(2)  # インストールをシミュレート
    return True

def main():
    try:
        config = json.loads(sys.argv[1])
        current_step = 1

        # WinRM設定
        update_progress("WinRM設定", "running", "WinRM設定を構成中...", current_step)
        setup_winrm()
        current_step += 1
        update_progress("WinRM設定", "completed", "WinRM設定が完了しました", current_step)

        # PSTools設定
        update_progress("PSTools設定", "running", "PSToolsのセットアップを開始...", current_step)
        setup_pstools()
        current_step += 1
        update_progress("PSTools設定", "completed", "PSToolsのセットアップが完了しました", current_step)

        # Windows Update設定
        update_progress("Windows Update設定", "running", "Windows Update設定を構成中...", current_step)
        configure_windows_update()
        current_step += 1
        update_progress("Windows Update設定", "completed", "Windows Update設定が完了しました", current_step)

        # ソフトウェアインストール
        if any(config.get('installOptions', {}).values()):
            update_progress("ソフトウェアインストール", "running", "選択されたソフトウェアをインストール中...", current_step)
            
            install_options = config.get('installOptions', {})
            if install_options.get('office365'):
                install_software('Office 365')
            if install_options.get('carbonBlack'):
                install_software('Carbon Black')
            if install_options.get('aresStandard'):
                install_software('ARES Standard')
            if install_options.get('trendMicro'):
                install_software('Trend Micro')
            if install_options.get('jp1Director'):
                install_software('JP1/Director')
            
            current_step += 1
            update_progress("ソフトウェアインストール", "completed", "すべてのソフトウェアのインストールが完了しました", current_step)

    except Exception as e:
        update_progress("エラー", "error", str(e), current_step)
        sys.exit(1)

if __name__ == "__main__":
    main()