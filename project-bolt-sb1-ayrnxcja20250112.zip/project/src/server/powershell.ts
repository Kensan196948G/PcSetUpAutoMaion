import { PowerShell } from 'node-powershell';
import type { PCSetupConfig, SetupProgress } from '../types/setup';
import { WebSocket } from 'ws';
import { logger } from './logger';
import { execSync } from 'child_process';

// PowerShellのパスを動的に取得
function getPowerShellPath(): string {
  try {
    if (process.platform === 'win32') {
      // Windowsの場合、whereコマンドでpowershell.exeのパスを取得
      const path = execSync('where powershell.exe').toString().split('\n')[0].trim();
      return path || 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';
    } else {
      // Unix系の場合、whichコマンドでpwshのパスを取得
      const path = execSync('which pwsh').toString().trim();
      return path || '/usr/bin/pwsh';
    }
  } catch (error) {
    // デフォルトのパスを返す
    return process.platform === 'win32'
      ? 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe'
      : '/usr/bin/pwsh';
  }
}

const POWERSHELL_PATH = getPowerShellPath();

// PowerShellインスタンスを作成する関数
function createPowerShellInstance(): PowerShell {
  return new PowerShell({
    executionPolicy: 'Bypass',
    noProfile: true,
    debugMsg: true,
    pwsh: false,
    exe: POWERSHELL_PATH,
    spawnOptions: {
      shell: true, // シェル経由で実行
      windowsHide: true,
      env: {
        ...process.env,
        TERM: 'xterm-256color'
      }
    }
  });
}

async function updateProgress(
  ws: WebSocket,
  step: string,
  status: 'pending' | 'running' | 'completed' | 'error',
  message: string,
  currentStep: number = 0,
  error?: Error
) {
  const progress: SetupProgress = {
    currentStep,
    totalSteps: 10,
    status: {
      step,
      status,
      message,
      error: error ? {
        message: error.message,
        stack: error.stack
      } : undefined
    }
  };

  ws.send(JSON.stringify(progress));
  logger.log(progress);
}

async function retryOperation(
  operation: () => Promise<any>,
  operationName: string,
  ws: WebSocket,
  currentStep: number,
  maxRetries: number = 3
) {
  let lastError: Error | undefined;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      await operation();
      return;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      
      if (attempt < maxRetries) {
        await updateProgress(
          ws,
          operationName,
          'running',
          `リトライ中... (${attempt}/${maxRetries})`,
          currentStep,
          lastError
        );
        await new Promise(resolve => setTimeout(resolve, 2000 * attempt));
      }
    }
  }
  
  throw lastError;
}

export async function setupWinRM(ps: PowerShell, config: PCSetupConfig, ws: WebSocket) {
  let currentStep = 1;
  
  try {
    await updateProgress(ws, 'WinRM設定', 'running', '接続元PCのWinRM設定を構成中...', currentStep);
    
    const psInstance = createPowerShellInstance();
    try {
      await retryOperation(
        async () => {
          const result = await psInstance.invoke(`
            # 接続元PCのWinRM設定
            $ErrorActionPreference = 'Stop'
            try {
              Enable-PSRemoting -Force
              winrm quickconfig -force
              winrm set winrm/config/service @{AllowUnencrypted="true"}
              winrm set winrm/config/service/auth @{Basic="true"}
              winrm set winrm/config/client @{TrustedHosts="*"}
            } catch {
              throw "WinRM設定エラー: $($_.Exception.Message)"
            }
          `);
          
          if (result.hadErrors) {
            throw new Error(result.errors.join('\n'));
          }
        },
        'WinRM設定（接続元PC）',
        ws,
        currentStep
      );

      await updateProgress(ws, 'WinRM設定', 'completed', '接続元PCのWinRM設定が完了しました', currentStep + 1);
      currentStep++;
    } finally {
      await psInstance.dispose();
    }

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    await updateProgress(ws, 'WinRM設定', 'error', `エラー: ${errorMessage}`, currentStep, error instanceof Error ? error : undefined);
    throw error;
  }
}

export async function setupPSTools(ps: PowerShell, config: PCSetupConfig, ws: WebSocket) {
  let currentStep = 2;

  try {
    await updateProgress(ws, 'PSTools設定', 'running', 'PSToolsのセットアップを開始...', currentStep);

    const psInstance = createPowerShellInstance();
    try {
      await retryOperation(
        async () => {
          const result = await psInstance.invoke(`
            # PSToolsのセットアップ
            $ErrorActionPreference = 'Stop'
            try {
              # PSToolsのダウンロードと展開
              $psToolsUrl = "https://download.sysinternals.com/files/PSTools.zip"
              $psToolsPath = "$env:TEMP\\PSTools.zip"
              $psToolsExtractPath = "$env:TEMP\\PSTools"

              # 既存のファイルがあれば削除
              if (Test-Path $psToolsPath) { Remove-Item $psToolsPath -Force }
              if (Test-Path $psToolsExtractPath) { Remove-Item $psToolsExtractPath -Force -Recurse }

              # ダウンロードと展開
              Invoke-WebRequest -Uri $psToolsUrl -OutFile $psToolsPath
              Expand-Archive -Path $psToolsPath -DestinationPath $psToolsExtractPath

              # PATHに追加
              $currentPath = [Environment]::GetEnvironmentVariable("Path", "Machine")
              if (-not $currentPath.Contains($psToolsExtractPath)) {
                [Environment]::SetEnvironmentVariable("Path", "$currentPath;$psToolsExtractPath", "Machine")
              }
            } catch {
              throw "PSToolsセットアップエラー: $($_.Exception.Message)"
            }
          `);

          if (result.hadErrors) {
            throw new Error(result.errors.join('\n'));
          }
        },
        'PSToolsセットアップ',
        ws,
        currentStep
      );

      await updateProgress(ws, 'PSTools設定', 'completed', 'PSToolsのセットアップが完了しました', currentStep + 1);
      currentStep++;
    } finally {
      await psInstance.dispose();
    }

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    await updateProgress(ws, 'PSTools設定', 'error', `エラー: ${errorMessage}`, currentStep, error instanceof Error ? error : undefined);
    throw error;
  }
}

export async function runSetupTasks(ps: PowerShell, config: PCSetupConfig, ws: WebSocket) {
  let currentStep = 3;

  try {
    // Windows Update設定
    await updateProgress(ws, 'Windows Update設定', 'running', 'Windows Updateの設定を構成中...', currentStep);
    
    const psInstance = createPowerShellInstance();
    try {
      await retryOperation(
        async () => {
          const result = await psInstance.invoke(`
            # Windows Update設定の構成
            $ErrorActionPreference = 'Stop'
            try {
              # Windows Update設定
              $AUSettings = (New-Object -com "Microsoft.Update.AutoUpdate").Settings
              $AUSettings.NotificationLevel = 4
              $AUSettings.ScheduledInstallationDay = 0
              $AUSettings.ScheduledInstallationTime = 3
              $AUSettings.IncludeRecommendedUpdates = $true
              $AUSettings.NonAdministratorsElevated = $true
              $AUSettings.FeaturedUpdatesEnabled = $true
              $AUSettings.Save()

              # Windows Updateサービスの再起動
              Restart-Service wuauserv -Force
            } catch {
              throw "Windows Update設定エラー: $($_.Exception.Message)"
            }
          `);

          if (result.hadErrors) {
            throw new Error(result.errors.join('\n'));
          }
        },
        'Windows Update設定',
        ws,
        currentStep
      );

      await updateProgress(ws, 'Windows Update設定', 'completed', 'Windows Update設定が完了しました', currentStep + 1);
      currentStep++;
    } finally {
      await psInstance.dispose();
    }

    // インストールオプションの処理
    if (Object.values(config.installOptions).some(value => value)) {
      await updateProgress(ws, 'ソフトウェアインストール', 'running', '選択されたソフトウェアをインストール中...', currentStep);

      const installTasks = [];

      if (config.installOptions.office365) {
        installTasks.push(installOffice365(ws, currentStep));
      }

      if (config.installOptions.carbonBlack) {
        installTasks.push(installCarbonBlack(ws, currentStep));
      }

      if (config.installOptions.aresStandard) {
        installTasks.push(installAresStandard(ws, currentStep));
      }

      if (config.installOptions.trendMicro) {
        installTasks.push(installTrendMicro(ws, currentStep));
      }

      if (config.installOptions.jp1Director) {
        installTasks.push(installJP1Director(ws, currentStep));
      }

      await Promise.all(installTasks);
      await updateProgress(ws, 'ソフトウェアインストール', 'completed', 'すべてのソフトウェアのインストールが完了しました', currentStep + 1);
    }

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    await updateProgress(ws, '実行中のタスク', 'error', `エラー: ${errorMessage}`, currentStep, error instanceof Error ? error : undefined);
    throw error;
  }
}

// ソフトウェアインストール関数
async function installOffice365(ws: WebSocket, currentStep: number) {
  const psInstance = createPowerShellInstance();
  try {
    await retryOperation(
      async () => {
        const result = await psInstance.invoke(`
          # Office 365のインストール
          # 実際のインストールコマンドをここに追加
          Write-Host "Office 365のインストールを開始します"
        `);
        if (result.hadErrors) throw new Error(result.errors.join('\n'));
      },
      'Office 365インストール',
      ws,
      currentStep
    );
  } finally {
    await psInstance.dispose();
  }
}

async function installCarbonBlack(ws: WebSocket, currentStep: number) {
  const psInstance = createPowerShellInstance();
  try {
    await retryOperation(
      async () => {
        const result = await psInstance.invoke(`
          # Carbon Blackのインストール
          # 実際のインストールコマンドをここに追加
          Write-Host "Carbon Blackのインストールを開始します"
        `);
        if (result.hadErrors) throw new Error(result.errors.join('\n'));
      },
      'Carbon Blackインストール',
      ws,
      currentStep
    );
  } finally {
    await psInstance.dispose();
  }
}

async function installAresStandard(ws: WebSocket, currentStep: number) {
  const psInstance = createPowerShellInstance();
  try {
    await retryOperation(
      async () => {
        const result = await psInstance.invoke(`
          # ARES Standardのインストール
          # 実際のインストールコマンドをここに追加
          Write-Host "ARES Standardのインストールを開始します"
        `);
        if (result.hadErrors) throw new Error(result.errors.join('\n'));
      },
      'ARES Standardインストール',
      ws,
      currentStep
    );
  } finally {
    await psInstance.dispose();
  }
}

async function installTrendMicro(ws: WebSocket, currentStep: number) {
  const psInstance = createPowerShellInstance();
  try {
    await retryOperation(
      async () => {
        const result = await psInstance.invoke(`
          # Trend Microのインストール
          # 実際のインストールコマンドをここに追加
          Write-Host "Trend Microのインストールを開始します"
        `);
        if (result.hadErrors) throw new Error(result.errors.join('\n'));
      },
      'Trend Microインストール',
      ws,
      currentStep
    );
  } finally {
    await psInstance.dispose();
  }
}

async function installJP1Director(ws: WebSocket, currentStep: number) {
  const psInstance = createPowerShellInstance();
  try {
    await retryOperation(
      async () => {
        const result = await psInstance.invoke(`
          # JP1/Directorのインストール
          # 実際のインストールコマンドをここに追加
          Write-Host "JP1/Directorのインストールを開始します"
        `);
        if (result.hadErrors) throw new Error(result.errors.join('\n'));
      },
      'JP1/Directorインストール',
      ws,
      currentStep
    );
  } finally {
    await psInstance.dispose();
  }
}

export { createPowerShellInstance };