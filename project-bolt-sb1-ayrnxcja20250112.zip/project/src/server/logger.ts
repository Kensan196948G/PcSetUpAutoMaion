import fs from 'fs';
import path from 'path';
import { SetupProgress } from '../types/setup';

class Logger {
  private logDir: string;
  private currentLogFile: string;

  constructor() {
    this.logDir = path.join(process.cwd(), 'logs');
    this.ensureLogDirectory();
    this.currentLogFile = this.createLogFile();
  }

  private ensureLogDirectory() {
    if (!fs.existsSync(this.logDir)) {
      fs.mkdirSync(this.logDir, { recursive: true });
    }
  }

  private createLogFile(): string {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const filename = `setup-log-${timestamp}.txt`; // ファイル名をより明確に
    const filepath = path.join(this.logDir, filename);
    
    // ログファイルのヘッダーを書き込む
    fs.writeFileSync(filepath, 'PCセットアップ実行ログ\n' +
      '==================\n\n' +
      `開始時刻: ${new Date().toLocaleString()}\n\n`);
    
    return filepath;
  }

  log(progress: SetupProgress) {
    const timestamp = new Date().toLocaleString();
    const { status } = progress;
    
    // 人間が読みやすい形式でログを記録
    const logEntry = `[${timestamp}] ${status.step}\n` +
      `状態: ${this.getStatusText(status.status)}\n` +
      `${status.message}\n`;
    
    if (status.error) {
      const errorLog = `エラー詳細:\n` +
        `  メッセージ: ${status.error.message}\n` +
        `  スタックトレース:\n${status.error.stack}\n`;
      fs.appendFileSync(this.currentLogFile, logEntry + errorLog + '\n');
    } else {
      fs.appendFileSync(this.currentLogFile, logEntry + '\n');
    }
  }

  private getStatusText(status: string): string {
    const statusMap: { [key: string]: string } = {
      'pending': '待機中',
      'running': '実行中',
      'completed': '完了',
      'error': 'エラー'
    };
    return statusMap[status] || status;
  }

  getLogFilePath(): string {
    return this.currentLogFile;
  }
}

export const logger = new Logger();