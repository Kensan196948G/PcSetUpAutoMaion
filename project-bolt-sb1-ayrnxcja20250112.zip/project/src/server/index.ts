import express from 'express';
import { WebSocketServer } from 'ws';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { PowerShell } from 'node-powershell';
import { setupWinRM, setupPSTools, runSetupTasks, createPowerShellInstance } from './powershell';
import type { PCSetupConfig } from '../types/setup';
import { logger } from './logger';

const app = express();
const port = process.env.PORT || 3000;
const wsPort = process.env.WS_PORT || 3001;

app.use(cors());
app.use(express.json());

// WebSocketサーバーの設定
const wss = new WebSocketServer({ 
  port: Number(wsPort),
  perMessageDeflate: false, // パフォーマンス向上のため無効化
  clientTracking: true, // クライアント追跡を有効化
});

// WebSocket接続のエラーハンドリング
wss.on('error', (error) => {
  console.error('WebSocketサーバーエラー:', error);
});

// クライアント接続管理用のSet
const connectedClients = new Set<WebSocket>();

wss.on('connection', (ws) => {
  console.log('新しいWebSocket接続が確立されました');
  connectedClients.add(ws);
  
  // 接続確認用のping-pongメカニズム
  const pingInterval = setInterval(() => {
    if (ws.readyState === ws.OPEN) {
      ws.ping();
    }
  }, 30000);

  ws.on('pong', () => {
    // pongを受信したら接続が生きていることを確認
    ws.isAlive = true;
  });
  
  ws.on('error', (error) => {
    console.error('WebSocketクライアントエラー:', error);
  });

  ws.on('close', () => {
    console.log('WebSocket接続が閉じられました');
    connectedClients.delete(ws);
    clearInterval(pingInterval);
  });

  // 初期状態を送信
  ws.send(JSON.stringify({
    currentStep: 0,
    totalSteps: 10,
    status: {
      step: '準備完了',
      status: 'pending',
      message: 'セットアップを開始できます'
    }
  }));
});

// 定期的に接続をチェック
const interval = setInterval(() => {
  wss.clients.forEach((ws) => {
    if (!ws.isAlive) {
      console.log('応答のないクライアントを切断します');
      return ws.terminate();
    }
    ws.isAlive = false;
    ws.ping();
  });
}, 30000);

wss.on('close', () => {
  clearInterval(interval);
});

// ヘルスチェックエンドポイント
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'ok',
    wsClients: connectedClients.size
  });
});

// セットアップ開始エンドポイント
app.post('/api/setup', async (req, res) => {
  const config: PCSetupConfig = req.body;

  try {
    // バリデーション
    if (!config.hostname) {
      throw new Error('ホスト名が必要です');
    }

    // PowerShellインスタンスの作成
    const ps = createPowerShellInstance();

    // アクティブなWebSocket接続を取得
    const ws = Array.from(connectedClients)[0];
    if (!ws) {
      throw new Error('WebSocket接続が確立されていません');
    }

    try {
      // WinRMのセットアップ
      await setupWinRM(ps, config, ws);

      // PSToolsのセットアップ
      await setupPSTools(ps, config, ws);

      // その他のセットアップタスクの実行
      await runSetupTasks(ps, config, ws);

      res.json({ 
        status: 'success',
        message: 'セットアップが完了しました',
        logPath: logger.getLogFilePath()
      });
    } catch (error) {
      console.error('セットアップエラー:', error);
      res.status(500).json({
        status: 'error',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    } finally {
      await ps.dispose();
    }
  } catch (error) {
    console.error('セットアップ開始エラー:', error);
    res.status(500).json({
      status: 'error',
      message: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

// ログファイルへのアクセス
app.get('/api/logs/current', (req, res) => {
  try {
    const logPath = logger.getLogFilePath();
    if (!logPath) {
      return res.status(404).json({ error: 'ログファイルが見つかりません' });
    }

    if (!fs.existsSync(logPath)) {
      return res.status(404).json({ error: 'ログファイルが存在しません' });
    }

    res.setHeader('Content-Disposition', `attachment; filename="${path.basename(logPath)}"`);
    res.setHeader('Content-Type', 'text/plain');

    const fileStream = fs.createReadStream(logPath);
    fileStream.pipe(res);
  } catch (error) {
    console.error('ログファイル取得エラー:', error);
    res.status(500).json({ error: 'ログファイルの取得に失敗しました' });
  }
});

// サーバーの起動
const server = app.listen(port, () => {
  console.log(`サーバーが起動しました: http://localhost:${port}`);
  console.log(`WebSocketサーバーが起動しました: ws://localhost:${wsPort}`);
});