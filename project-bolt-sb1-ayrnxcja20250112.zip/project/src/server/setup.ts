import { PowerShell } from 'node-powershell';
import type { PCSetupConfig, SetupProgress } from '../types/setup';
import { WebSocket } from 'ws';
import { logger } from './logger';

async function updateProgress(
  ws: WebSocket,
  step: string,
  status: 'pending' | 'running' | 'completed' | 'error',
  message: string,
  currentStep: number = 0,
  error?: Error
) {
  const progress: SetupProgress = {
    currentStep,
    totalSteps: 10,
    status: {
      step,
      status,
      message,
      error: error ? {
        message: error.message,
        stack: error.stack
      } : undefined
    }
  };

  ws.send(JSON.stringify(progress));
  logger.log(progress);
}

async function retryOperation(
  operation: () => Promise<any>,
  operationName: string,
  ws: WebSocket,
  currentStep: number,
  maxRetries: number = 3
) {
  let lastError: Error | undefined;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      await operation();
      return;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      
      if (attempt < maxRetries) {
        await updateProgress(
          ws,
          operationName,
          'running',
          `リトライ中... (${attempt}/${maxRetries})`,
          currentStep,
          lastError
        );
        await new Promise(resolve => setTimeout(resolve, 2000 * attempt));
      }
    }
  }
  
  throw lastError;
}

async function configureDesktopIcons(ps: PowerShell, ws: WebSocket, currentStep: number) {
  await retryOperation(
    async () => {
      const result = await ps.invoke(`
        # デスクトップアイコンの設定
        $ErrorActionPreference = 'Stop'
        try {
          # コンピューターとユーザーファイルのアイコンを表示
          reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\HideDesktopIcons\\NewStartPanel" /v "{20D04FE0-3AEA-1069-A2D8-08002B30309D}" /t REG_DWORD /d 0 /f
          reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\HideDesktopIcons\\NewStartPanel" /v "{59031a47-3f72-44a7-89c5-5595fe6b30ee}" /t REG_DWORD /d 0 /f

          # デスクトップアイコンを種類で並び替え
          reg add "HKCU\\Software\\Microsoft\\Windows\\Shell\\Bags\\1\\Desktop" /v "FFlags" /t REG_DWORD /d 1075839520 /f
          reg add "HKCU\\Software\\Microsoft\\Windows\\Shell\\Bags\\1\\Desktop" /v "Mode" /t REG_DWORD /d 1 /f

          # エクスプローラーを再起動して設定を反映
          Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
          Start-Process explorer
        } catch {
          throw "デスクトップアイコン設定エラー: $($_.Exception.Message)"
        }
      `);
      if (result.hadErrors) throw new Error(result.errors.join('\n'));
    },
    'デスクトップアイコン設定',
    ws,
    currentStep
  );
}

async function setDefaultPdfProgram(ps: PowerShell, ws: WebSocket, currentStep: number) {
  await retryOperation(
    async () => {
      const result = await ps.invoke(`
        # PDFの既定のプログラム設定
        $ErrorActionPreference = 'Stop'
        try {
          # Adobe Acrobat Reader DCの確認
          $adobeReaderPath = Get-ItemProperty "HKLM:\\SOFTWARE\\Adobe\\Acrobat Reader\\DC\\Installer" -ErrorAction SilentlyContinue
          if (-not $adobeReaderPath) {
            throw "Adobe Acrobat Reader DCがインストールされていません"
          }

          # PDF関連の設定
          $pdfExtensions = @('.pdf', '.pdx')
          foreach ($ext in $pdfExtensions) {
            reg add "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\$ext\\UserChoice" /v "ProgId" /t REG_SZ /d "AcroExch.Document.DC" /f
            reg add "HKCU\\Software\\Classes\\$ext" /ve /t REG_SZ /d "AcroExch.Document.DC" /f
          }

          # 設定を反映
          Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
          Start-Process explorer
        } catch {
          throw "PDFの既定のプログラム設定エラー: $($_.Exception.Message)"
        }
      `);
      if (result.hadErrors) throw new Error(result.errors.join('\n'));
    },
    'PDFの既定のプログラム設定',
    ws,
    currentStep
  );
}

export async function runSetup(config: PCSetupConfig, ws: WebSocket): Promise<void> {
  let currentStep = 1;
  const ps = new PowerShell({
    executionPolicy: 'Bypass',
    noProfile: true
  });

  try {
    // デスクトップアイコン設定
    if (config.osSettings.desktopIcons) {
      await updateProgress(ws, 'デスクトップアイコン設定', 'running', 'デスクトップアイコンを設定中...', currentStep);
      await configureDesktopIcons(ps, ws, currentStep);
      await updateProgress(ws, 'デスクトップアイコン設定', 'completed', 'デスクトップアイコンの設定が完了しました', currentStep);
      currentStep++;
    }

    // PDFの既定のプログラム設定
    if (config.osSettings.defaultPdfProgram) {
      await updateProgress(ws, 'PDFの既定のプログラム設定', 'running', 'PDFの既定のプログラムを設定中...', currentStep);
      await setDefaultPdfProgram(ps, ws, currentStep);
      await updateProgress(ws, 'PDFの既定のプログラム設定', 'completed', 'PDFの既定のプログラム設定が完了しました', currentStep);
      currentStep++;
    }

    // セットアップ完了
    await updateProgress(ws, 'セットアップ完了', 'completed', 'すべてのセットアップが完了しました', currentStep);

  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    await updateProgress(ws, '実行中のタスク', 'error', `エラー: ${errorMessage}`, currentStep, error instanceof Error ? error : undefined);
    throw error;
  } finally {
    await ps.dispose();
  }
}