import React, { useEffect, useState } from 'react';
import { Loader2, FileText, AlertCircle, RefreshCw, CheckCircle } from 'lucide-react';
import type { SetupProgress } from '../types/setup';

interface SetupProgressProps {
  progress: SetupProgress | null;
}

export function SetupProgress({ progress }: SetupProgressProps) {
  const [logUrl, setLogUrl] = useState<string | null>(null);
  const [showErrorDetails, setShowErrorDetails] = useState(false);

  useEffect(() => {
    if (progress?.status.status === 'completed' || progress?.status.status === 'error') {
      fetch('http://localhost:3000/api/logs/current')
        .then(res => res.json())
        .then(data => {
          setLogUrl(data.path);
        })
        .catch(console.error);
    }
  }, [progress?.status.status]);

  if (!progress) return null;

  const { currentStep, totalSteps, status } = progress;
  const percentage = Math.round((currentStep / totalSteps) * 100);

  return (
    <div className="mt-6 bg-white shadow-lg rounded-lg p-6">
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-medium text-gray-900">セットアップ進捗</h3>
          <span className="text-sm font-medium text-gray-500">
            {currentStep} / {totalSteps} ステップ
          </span>
        </div>

        <div className="relative">
          <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
            <div
              style={{ width: `${percentage}%` }}
              className={`shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center transition-all duration-500 ${
                status.status === 'error' ? 'bg-red-500' :
                status.status === 'completed' ? 'bg-green-500' :
                'bg-blue-500'
              }`}
            />
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {status.status === 'running' && status.message?.includes('リトライ') ? (
            <RefreshCw className="w-5 h-5 text-orange-500 animate-spin" />
          ) : status.status === 'running' ? (
            <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
          ) : status.status === 'error' ? (
            <AlertCircle className="w-5 h-5 text-red-500" />
          ) : status.status === 'completed' ? (
            <CheckCircle className="w-5 h-5 text-green-500" />
          ) : null}
          <span className={`font-medium ${
            status.status === 'error' ? 'text-red-600' :
            status.status === 'completed' ? 'text-green-600' :
            'text-gray-900'
          }`}>
            {status.step}
          </span>
        </div>

        {status.message && (
          <p className={`text-sm ${
            status.message.includes('リトライ') ? 'text-orange-500' :
            status.status === 'error' ? 'text-red-500' :
            'text-gray-500'
          }`}>
            {status.message}
          </p>
        )}

        {status.error && (
          <div className="mt-2">
            <button
              onClick={() => setShowErrorDetails(!showErrorDetails)}
              className="text-sm text-red-600 hover:text-red-700 flex items-center gap-1"
            >
              <span>{showErrorDetails ? 'エラーの詳細を隠す' : 'エラーの詳細を表示'}</span>
            </button>
            {showErrorDetails && (
              <pre className="mt-2 p-3 bg-red-50 text-red-700 rounded text-xs overflow-auto">
                {status.error.stack || status.error.message}
              </pre>
            )}
          </div>
        )}

        {logUrl && (
          <div className="mt-4 flex items-center space-x-2 bg-gray-50 p-3 rounded-lg">
            <FileText className="w-5 h-5 text-blue-500" />
            <a
              href={logUrl}
              target="_blank"
              rel="noopener noreferrer"
              download
              className="text-sm text-blue-500 hover:text-blue-600 font-medium"
            >
              セットアップログをダウンロード
            </a>
          </div>
        )}
      </div>
    </div>
  );
}