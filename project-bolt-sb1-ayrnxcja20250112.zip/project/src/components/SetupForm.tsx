import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { Monitor, Shield, Package, Laptop, WifiOff, Settings, WindowsLogo } from 'lucide-react';
import type { PCSetupConfig } from '../types/setup';
import { SetupProgress } from './SetupProgress';
import { useWebSocket } from '../hooks/useWebSocket';

export function SetupForm() {
  const [serverStatus, setServerStatus] = useState<'checking' | 'online' | 'offline'>('checking');
  const { register, handleSubmit, watch, setValue } = useForm<PCSetupConfig>({
    defaultValues: {
      setupType: 'LOCAL',
      username: 'mirai-user',
      installOptions: {
        office365: false,
        carbonBlack: false,
        aresStandard: false,
        trendMicroApexOne: false,
        trendMicroVirusBuster: false,
        jp1Director: false,
        dvdSoftware: false,
        fortiClientVpn: false
      },
      osSettings: {
        desktopIcons: false,
        disableIpv6: false,
        disableWindowsDefenderFw: false,
        unpinMailStore: false,
        edgeDefaultSites: false,
        edgeDefaultBrowser: false,
        defaultMailProgram: false,
        defaultPdfProgram: false,
        windowsUpdate: {
          enabled: false,
          microsoftUpdate: false,
          systemCleanup: false,
          diskCleanup: false,
          autoRestart: false
        }
      }
    }
  });
  
  const setupType = watch('setupType');
  const username = watch('username');
  const { progress } = useWebSocket();

  useEffect(() => {
    checkServerStatus();
    const interval = setInterval(checkServerStatus, 5000);
    return () => clearInterval(interval);
  }, []);

  const checkServerStatus = async () => {
    try {
      const response = await fetch('/api/health');
      if (response.ok) {
        setServerStatus('online');
      } else {
        setServerStatus('offline');
      }
    } catch {
      setServerStatus('offline');
    }
  };

  const onSubmit = async (data: PCSetupConfig) => {
    try {
      const response = await fetch('/api/setup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'セットアップの開始に失敗しました');
      }
    } catch (error) {
      console.error('Error:', error);
      alert(error instanceof Error ? error.message : 'サーバーに接続できません。サーバーが起動しているか確認してください。');
    }
  };

  const handleUsernameChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setValue('username', event.target.value);
  };

  return (
    <div className="space-y-6 max-w-2xl mx-auto bg-white p-6 rounded-lg shadow-md">
      {serverStatus === 'offline' && (
        <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-4">
          <div className="flex items-center">
            <WifiOff className="h-5 w-5 text-red-400 mr-2" />
            <div>
              <p className="text-sm text-red-700">
                サーバーに接続できません。以下を確認してください：
              </p>
              <ul className="list-disc list-inside text-sm text-red-600 mt-2">
                <li>サーバーが起動しているか（npm run server）</li>
                <li>正しいポートで動作しているか（デフォルト：3000）</li>
                <li>ファイアウォールの設定</li>
              </ul>
              <button
                onClick={checkServerStatus}
                className="mt-2 text-sm text-red-700 hover:text-red-800 underline"
              >
                再接続を試みる
              </button>
            </div>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* 基本設定 */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Laptop className="w-5 h-5" />
            基本設定
          </h2>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              ホスト名/IPアドレス（いずれか1つを入力）
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="ホスト名またはIPアドレス"
                {...register('hostname')}
                className="mt-1 block w-full rounded-md border-2 border-blue-200 bg-blue-50 shadow-sm focus:border-blue-500 focus:ring-blue-500 placeholder-gray-400"
              />
              <p className="mt-1 text-xs text-gray-500">例: PC-001 または 192.168.1.100</p>
            </div>
          </div>
        </div>

        {/* セットアップタイプ */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Monitor className="w-5 h-5" />
            セットアップタイプ
          </h2>
          <div className="grid grid-cols-1 gap-4">
            <label className={`relative flex cursor-pointer rounded-lg border-2 p-4 shadow-sm focus:outline-none transition-colors ${
              setupType === 'LOCAL' ? 'bg-blue-50 border-blue-500' : 'bg-white border-gray-200 hover:border-blue-300'
            }`}>
              <input
                type="radio"
                {...register('setupType')}
                value="LOCAL"
                className="sr-only"
              />
              <span className="flex flex-1">
                <span className="flex flex-col">
                  <span className={`block text-sm font-medium ${
                    setupType === 'LOCAL' ? 'text-blue-900' : 'text-gray-900'
                  }`}>ローカル</span>
                  <span className="mt-1 text-xs text-gray-500">既存ローカル環境用</span>
                </span>
              </span>
              <Monitor className={`h-5 w-5 ${
                setupType === 'LOCAL' ? 'text-blue-600' : 'text-gray-400'
              }`} aria-hidden="true" />
            </label>
          </div>
        </div>

        {/* ユーザー情報 */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Shield className="w-5 h-5" />
            ユーザー情報
          </h2>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">ユーザー名</label>
              <select
                value={username}
                onChange={handleUsernameChange}
                className="mt-1 block w-full rounded-md border-2 border-blue-200 bg-blue-50 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              >
                <option value="mirai-user">mirai-user</option>
                <option value="l-admin">l-admin</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">パスワード</label>
              <input
                type="password"
                {...register('password')}
                className="mt-1 block w-full rounded-md border-2 border-blue-200 bg-blue-50 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                placeholder="パスワードを入力"
              />
            </div>
          </div>
        </div>

        {/* OS設定 */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Settings className="w-5 h-5" />
            OS設定
          </h2>
          <div className="space-y-2">
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('osSettings.desktopIcons')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">デスクトップアイコンの設定</span>
            </label>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('osSettings.disableIpv6')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">IPv6の無効化</span>
            </label>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('osSettings.disableWindowsDefenderFw')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Windows Defender F/Wの無効化</span>
            </label>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('osSettings.unpinMailStore')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Mail、Storeのピン留めを外す</span>
            </label>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('osSettings.edgeDefaultSites')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Edgeのデフォルトサイトの設定</span>
            </label>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('osSettings.edgeDefaultBrowser')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Edgeを既定のブラウザに設定</span>
            </label>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('osSettings.defaultMailProgram')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">既定のメールプログラムを設定（Outlook365）</span>
            </label>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('osSettings.defaultPdfProgram')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">既定のPDFプログラムを設定（Adobe Acrobat Reader DC）</span>
            </label>
          </div>
        </div>

        {/* インストールオプション */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold flex items-center gap-2">
            <Package className="w-5 h-5" />
            インストールオプション
          </h2>
          <div className="space-y-2">
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('installOptions.office365')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Office 365</span>
            </label>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('installOptions.carbonBlack')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Carbon Black</span>
            </label>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('installOptions.aresStandard')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">ARES Standard</span>
            </label>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('installOptions.trendMicroApexOne')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Trend Micro Apex One</span>
            </label>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('installOptions.trendMicroVirusBuster')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">Trend Micro ウィルスバスタークラウド</span>
            </label>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('installOptions.jp1Director')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">JP1/Director</span>
            </label>
            <label className="flex items-center space-x-3">
              <input
                type="checkbox"
                {...register('installOptions.fortiClientVpn')}
                className="rounded border-gray-300 text-blue-600 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">FortiClient VPN</span>
            </label>
          </div>
        </div>

        <button
          type="submit"
          disabled={serverStatus === 'offline'}
          className={`w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white ${
            serverStatus === 'offline'
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500'
          }`}
        >
          セットアップを開始
        </button>
      </form>

      {progress && <SetupProgress progress={progress} />}
    </div>
  );
}